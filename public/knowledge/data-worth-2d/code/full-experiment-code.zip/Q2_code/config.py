"""Q2 - settings shared by all notebooks. Units: metres and days (K in m/d)."""

# Grid and aquifer
NROW, NCOL = 50, 50
DX = 10.0                                   # cell size [m]; domain 500 m x 500 m
TOP, BOT = 0.0, -10.0                       # confined aquifer, 10 m thick

# Boundary conditions
H_WEST, H_EAST = 10.0, 5.0                  # prescribed heads [m]; north and south no-flow; no recharge

# Random-function model of ln K
MEAN_LNK = 2.16                             # geometric-mean K = 8.67 m/d
VAR_LNK = 1.0
PRACTICAL_RANGE = 200.0                     # exponential covariance [m]

# Ensembles
N_ENS = 200
SEED_TRUTH = 2026
SEED_PRIOR = 1
SEED_NOISE = 99
SEED_ESMDA = 11                              # base seed; replicate r uses SEED_ESMDA + 100 r + stage index
N_REP = 5                                   # replicates: independent prior ensemble (SEED_PRIOR + r) and perturbation seeds
SEED_EXACT = 5

# Observation grids: k x k regular grids centred in the domain
GRID_SIZES = {4: 2, 16: 4, 36: 6}
SIGMA_LNK = 0.1                             # ln K measurement error (std)
SIGMA_H = 0.02                              # head measurement error (std) [m]

# Assimilation stages: (label, number of ln K data, number of heads)
STAGES = [("Prior", 0, 0),
          ("4 K", 4, 0),
          ("16 K", 16, 0),
          ("36 K", 36, 0),
          ("4 K + 4 h", 4, 4),
          ("4 K + 36 h", 4, 36),
          ("36 K + 36 h", 36, 36)]

# Data-worth steps: (label, stage before, stage after)
STEPS = [("4 K to the prior", "Prior", "4 K"),
         ("K: 4 to 16", "4 K", "16 K"),
         ("K: 16 to 36", "16 K", "36 K"),
         ("4 h to 4 K", "4 K", "4 K + 4 h"),
         ("h: 4 to 36 (4 K)", "4 K + 4 h", "4 K + 36 h"),
         ("36 h to 36 K", "36 K", "36 K + 36 h"),
         ("32 K to 4 K + 36 h", "4 K + 36 h", "36 K + 36 h")]

# ES-MDA
ALPHAS = [4.0, 4.0, 4.0, 4.0]               # sum of 1/alpha = 1
LOC_RADIUS = 200.0                          # Gaspari-Cohn localization half-width [m] (zero beyond 2 x radius)


MF6_EXE = "mf6"                             # full path to mf6.exe if not on the PATH

# Output folders (created automatically)
DATA = "results/data/"                      # fields, observations, ensembles
TABLES = "results/tables/"                  # csv tables used in the report
FIGS = "results/figures/"                   # figures used in the report
RUNS = "results/mf6_runs/"                  # MODFLOW 6 working folders

import os
for _d in (DATA, TABLES, FIGS, RUNS):
    os.makedirs(_d, exist_ok=True)
