"""Q2 - functions shared by the notebooks: fields, forward model, observations, ES-MDA, metrics, plotting."""
import numpy as np
import flopy
import matplotlib.pyplot as plt
import os
import config as cfg

# ---------------------------------------------------------------- grid and geostatistics
def cell_centres():
    x = (np.arange(cfg.NCOL) + 0.5) * cfg.DX
    y = (cfg.NROW - np.arange(cfg.NROW) - 0.5) * cfg.DX                    # row 0 = north
    X, Y = np.meshgrid(x, y)
    return np.column_stack([X.ravel(), Y.ravel()])

def covariance_matrix():
    p = cell_centres()
    h = np.sqrt(((p[:, None, :] - p[None, :, :]) ** 2).sum(-1))
    return cfg.VAR_LNK * np.exp(-3.0 * h / cfg.PRACTICAL_RANGE)

def simulate(L, n, seed, mean=None):
    """Gaussian realizations m = mean + L z (Cholesky / LU simulation)."""
    mean = cfg.MEAN_LNK if mean is None else mean
    z = np.random.default_rng(seed).standard_normal((L.shape[0], n))
    m = (np.reshape(mean, (-1, 1)) + L @ z).T
    return m.reshape(n, cfg.NROW, cfg.NCOL)

def variogram(field, max_lag=25):
    """Experimental semivariogram along rows and columns of a regular grid (lags in cells)."""
    g = []
    for l in range(1, max_lag + 1):
        d = np.concatenate([(field[:, l:] - field[:, :-l]).ravel(), (field[l:, :] - field[:-l, :]).ravel()])
        g.append(0.5 * np.mean(d ** 2))
    return np.arange(1, max_lag + 1) * cfg.DX, np.array(g)

def variogram_model(h):
    return cfg.VAR_LNK * (1.0 - np.exp(-3.0 * h / cfg.PRACTICAL_RANGE))

# ---------------------------------------------------------------- observation grids
def grid_cells(n):
    k = cfg.GRID_SIZES[n]
    ids = [int(((i + 0.5) * cfg.NCOL * cfg.DX / k) // cfg.DX) for i in range(k)]
    return [(r, c) for r in ids for c in ids]

def cell_xy(cells):
    return np.array([((c + 0.5) * cfg.DX, (cfg.NROW - r - 0.5) * cfg.DX) for r, c in cells])

# ---------------------------------------------------------------- forward model
class ForwardModel:
    """Steady 2-D confined flow (MODFLOW 6). run(lnk) -> heads [NROW, NCOL], outflow east [m3/d], inflow west [m3/d]."""
    def __init__(self, ws="model"):
        sim = flopy.mf6.MFSimulation(sim_name="sim", sim_ws=cfg.RUNS + ws, exe_name=cfg.MF6_EXE)
        flopy.mf6.ModflowTdis(sim, nper=1, perioddata=[(1.0, 1, 1.0)], time_units="days")
        flopy.mf6.ModflowIms(sim, complexity="SIMPLE", outer_dvclose=1e-8, inner_dvclose=1e-8)
        g = flopy.mf6.ModflowGwf(sim, modelname="gwf", save_flows=True)
        flopy.mf6.ModflowGwfdis(g, nlay=1, nrow=cfg.NROW, ncol=cfg.NCOL, delr=cfg.DX, delc=cfg.DX,
                                top=cfg.TOP, botm=cfg.BOT, length_units="meters")
        flopy.mf6.ModflowGwfic(g, strt=cfg.H_WEST)
        self.npf = flopy.mf6.ModflowGwfnpf(g, icelltype=0, k=1.0)
        flopy.mf6.ModflowGwfsto(g, steady_state={0: True})
        chd = [[(0, r, 0), cfg.H_WEST] for r in range(cfg.NROW)] + \
              [[(0, r, cfg.NCOL - 1), cfg.H_EAST] for r in range(cfg.NROW)]
        flopy.mf6.ModflowGwfchd(g, stress_period_data=chd)
        flopy.mf6.ModflowGwfoc(g, head_filerecord="gwf.hds", budget_filerecord="gwf.cbc",
                               saverecord=[("HEAD", "ALL"), ("BUDGET", "ALL")])
        sim.write_simulation(silent=True)
        self.sim, self.gwf = sim, g
        self.east = {r * cfg.NCOL + cfg.NCOL for r in range(cfg.NROW)}
        self.west = {r * cfg.NCOL + 1 for r in range(cfg.NROW)}

    def run(self, lnk):
        self.npf.k.set_data(np.exp(lnk))
        self.npf.write()
        ok, _ = self.sim.run_simulation(silent=True)
        if not ok:
            raise RuntimeError("MODFLOW 6 did not converge")
        h = self.gwf.output.head().get_data()[0]
        f = self.gwf.output.budget().get_data(text="CHD")[0]
        q_out = -sum(q for n, q in zip(f["node"], f["q"]) if n in self.east)
        q_in = sum(q for n, q in zip(f["node"], f["q"]) if n in self.west)
        return h, q_out, q_in

    def run_ensemble(self, E):
        out = [self.run(m) for m in E]
        return np.array([o[0] for o in out]), np.array([o[1] for o in out])

# ---------------------------------------------------------------- data and ES-MDA
def stage_data(obs, nK, nH):
    d = np.concatenate([obs[f"lnk_{nK}"] if nK else [], obs[f"h_{nH}"] if nH else []])
    sd = np.concatenate([np.full(nK, cfg.SIGMA_LNK), np.full(nH, cfg.SIGMA_H)])
    return d, sd

def predicted_data(E, obs, nK, nH, fm):
    out = []
    if nK:
        r, c = obs[f"cells_{nK}"].T
        out.append(E[:, r, c])
    if nH:
        r, c = obs[f"cells_{nH}"].T
        out.append(np.array([fm.run(m)[0][r, c] for m in E]))
    return np.hstack(out)

def gaspari_cohn(dist, radius):
    """Fifth-order compactly supported correlation function (Gaspari and Cohn, 1999)."""
    z = np.asarray(dist) / radius
    rho = np.zeros_like(z)
    a, b = z <= 1, (z > 1) & (z < 2)
    rho[a] = -0.25 * z[a] ** 5 + 0.5 * z[a] ** 4 + 0.625 * z[a] ** 3 - 5 / 3 * z[a] ** 2 + 1
    rho[b] = z[b] ** 5 / 12 - 0.5 * z[b] ** 4 + 0.625 * z[b] ** 3 + 5 / 3 * z[b] ** 2 - 5 * z[b] + 4 - 2 / (3 * z[b])
    return rho

def localization(obs, nK, nH, radius=cfg.LOC_RADIUS):
    """Localization matrices for C_MD (cells x data) and C_DD (data x data)."""
    p = cell_centres()
    dxy = np.vstack([cell_xy(obs[f"cells_{n}"]) for n in (nK, nH) if n])
    rho_md = gaspari_cohn(np.sqrt(((p[:, None] - dxy[None]) ** 2).sum(-1)), radius)
    rho_dd = gaspari_cohn(np.sqrt(((dxy[:, None] - dxy[None]) ** 2).sum(-1)), radius)
    return rho_md, rho_dd

def es_mda(prior, obs, nK, nH, fm, seed=cfg.SEED_ESMDA):
    """Ensemble smoother with multiple data assimilation (Emerick and Reynolds, 2013), with distance localization."""
    d_obs, sd = stage_data(obs, nK, nH)
    rho_md, rho_dd = localization(obs, nK, nH)
    n = prior.shape[0]
    M = prior.reshape(n, -1).copy()
    rng = np.random.default_rng(seed)
    for a in cfg.ALPHAS:
        D = predicted_data(M.reshape(prior.shape), obs, nK, nH, fm)
        dM, dD = M - M.mean(0), D - D.mean(0)
        C_MD = rho_md * (dM.T @ dD) / (n - 1)
        C_DD = rho_dd * (dD.T @ dD) / (n - 1)
        pert = d_obs + np.sqrt(a) * sd * rng.standard_normal(D.shape)
        M += np.linalg.solve(C_DD + a * np.diag(sd ** 2), (pert - D).T).T @ C_MD.T
    return M.reshape(prior.shape)

def exact_posterior(C, obs, nK, n, seed=cfg.SEED_EXACT):
    """Exact linear-Gaussian posterior for ln K data (simple kriging with measurement error) and conditional realizations."""
    r, c = obs[f"cells_{nK}"].T
    k = np.ravel_multi_index((r, c), (cfg.NROW, cfg.NCOL))
    A = C[:, k]
    W = np.linalg.solve(C[np.ix_(k, k)] + cfg.SIGMA_LNK ** 2 * np.eye(nK), A.T).T
    mean = cfg.MEAN_LNK + W @ (obs[f"lnk_{nK}"] - cfg.MEAN_LNK)
    Cp = C - W @ A.T
    L = np.linalg.cholesky(Cp + 1e-8 * np.eye(len(Cp)))
    return simulate(L, n, seed, mean=mean), np.diag(Cp).reshape(cfg.NROW, cfg.NCOL)

# ---------------------------------------------------------------- metrics and significance
def field_metrics(E, truth):
    mean = E.mean(0)
    lo, hi = np.percentile(E, [2.5, 97.5], axis=0)
    spread = E.var(0, ddof=1).mean()
    rmse = np.sqrt(((mean - truth) ** 2).mean())
    return {"lnk_spread": spread, "lnk_bias": (mean - truth).mean(), "lnk_rmse": rmse,
            "lnk_combined": spread + rmse ** 2, "lnk_mae": np.abs(mean - truth).mean(),
            "lnk_mean_sd": E.std(0, ddof=1).mean(), "lnk_coverage": ((truth >= lo) & (truth <= hi)).mean()}

def prediction_metrics(q, q_true):
    lo, hi = np.percentile(q, [2.5, 97.5])
    return {"q_mean": q.mean(), "q_sd": q.std(ddof=1), "q_bias": q.mean() - q_true,
            "q_combined": np.mean((q - q_true) ** 2), "q_p2.5": lo, "q_p97.5": hi,
            "q_covered": float(lo <= q_true <= hi)}

def variance_change(v1, v2, n):
    """Relative change of a variance and whether it exceeds twice its relative sampling error, 2*sqrt(2/(n-1))."""
    rel = v2 / v1 - 1.0
    return rel, abs(rel) > 2.0 * np.sqrt(2.0 / (n - 1))

def rmse_change(r1, r2, spread1, spread2, n):
    """Change of the ln K RMSE and whether it exceeds twice the sampling error of the ensemble mean, 2*sqrt(spread/n)."""
    dr = r2 - r1
    return dr, abs(dr) > 2.0 * np.sqrt(max(spread1, spread2) / n)

def mean_change(m1, m2, s1, s2, n):
    """Change of an ensemble mean and whether it exceeds twice its sampling error."""
    dm = m2 - m1
    return dm, abs(dm) > 2.0 * np.sqrt((s1 ** 2 + s2 ** 2) / n)

# ---------------------------------------------------------------- plotting
EXTENT = [0, cfg.NCOL * cfg.DX, 0, cfg.NROW * cfg.DX]
GROUP_COLOURS = {"Prior": "0.4", "K": "tab:blue", "4 K + h": "tab:orange", "all": "tab:green"}

def stage_group(label):
    if label == "Prior":
        return "Prior"
    if "h" not in label:
        return "K"
    return "all" if label.startswith("36 K") else "4 K + h"

def set_style():
    plt.rcParams.update({"font.size": 12, "axes.titlesize": 13, "axes.titleweight": "bold", "axes.labelsize": 12,
                         "legend.fontsize": 11, "legend.frameon": True, "legend.framealpha": 0.95, "legend.edgecolor": "0.6",
                         "xtick.labelsize": 11, "ytick.labelsize": 11, "axes.linewidth": 1.1, "lines.linewidth": 2.0,
                         "lines.markersize": 8, "figure.dpi": 110, "savefig.dpi": 300, "savefig.bbox": "tight",
                         "axes.grid": False})

def map_axes(ax, title=None, xlabel=True, ylabel=True):
    ax.set_xlim(EXTENT[:2]); ax.set_ylim(EXTENT[2:]); ax.set_aspect("equal")
    ax.set_xticks([0, 250, 500]); ax.set_yticks([0, 250, 500])
    ax.set_xlabel("x (m)" if xlabel else ""); ax.set_ylabel("y (m)" if ylabel else "")
    if not xlabel: ax.set_xticklabels([])
    if not ylabel: ax.set_yticklabels([])
    if title: ax.set_title(title)

def panel_label(ax, letter):
    ax.text(0.0, 1.02, f"({letter})", transform=ax.transAxes, ha="left", va="bottom", fontweight="bold", fontsize=14)

def side_colorbar(fig, ax, im, label):
    """Colorbar attached to the right of a single map, with the map's height."""
    from mpl_toolkits.axes_grid1 import make_axes_locatable
    cax = make_axes_locatable(ax).append_axes("right", size="4%", pad=0.08)
    return fig.colorbar(im, cax=cax, label=label)
