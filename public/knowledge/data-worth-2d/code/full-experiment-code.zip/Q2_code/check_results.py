"""Q2 - automatic checks of the code and results. Run after notebooks 01-03:  python check_results.py"""
import numpy as np
import pandas as pd
import config as cfg
import q2lib as q

results = []
def check(name, ok, detail):
    results.append((name, bool(ok), detail))

truth, prior = np.load((cfg.DATA + "lnk_truth.npy")), np.load((cfg.DATA + "lnk_prior.npy"))
obs = dict(np.load((cfg.DATA + "observations.npz")))
metrics = pd.read_csv((cfg.TABLES + "table_stage_metrics.csv"), index_col=0)                      # mean of the replicates
rep1 = pd.read_csv((cfg.TABLES + "table_replicates.csv")).query("replicate == 1").set_index("stage")   # replicate 1 = saved prior
exact = pd.read_csv((cfg.TABLES + "table_exact_posterior.csv"), index_col=0)
N = prior.shape[0]

# 1 Field generation reproduces the random-function model
h, g = q.variogram(prior[0]); G = np.array([q.variogram(f)[1] for f in prior])
err = np.abs(G.mean(0)[:10] - q.variogram_model(h[:10])).max()
check("Prior variogram matches the model (lags <= 100 m)", err < 0.08, f"max deviation {err:.3f}")
check("Prior mean and variance", abs(prior.mean() - cfg.MEAN_LNK) < 0.1 and abs(prior.var(0, ddof=1).mean() - cfg.VAR_LNK) < 0.1,
      f"mean {prior.mean():.3f}, variance {prior.var(0, ddof=1).mean():.3f}")

# 2 Forward model
fm = q.ForwardModel("check")
_, qu, qi = fm.run(np.full((cfg.NROW, cfg.NCOL), cfg.MEAN_LNK))
q_darcy = np.exp(cfg.MEAN_LNK) * (cfg.TOP - cfg.BOT) * cfg.NROW * cfg.DX * (cfg.H_WEST - cfg.H_EAST) / ((cfg.NCOL - 1) * cfg.DX)
check("Uniform K equals Darcy", abs(qu - q_darcy) / q_darcy < 1e-6, f"{qu:.3f} vs {q_darcy:.3f} m3/d")
h0, q0, qin = fm.run(truth)
check("Water balance of the reference", abs(qin - q0) / q0 < 1e-6, f"in {qin:.3f}, out {q0:.3f} m3/d")
h1, q1, _ = fm.run(truth + 1.0)
check("Heads invariant to the K level", np.abs(h1 - h0).max() < 1e-6, f"max change {np.abs(h1 - h0).max():.1e} m")
check("Outflow proportional to the K level", abs(q1 / q0 - np.e) < 1e-4, f"ratio {q1 / q0:.5f}")
check("Stored true outflow is the reference outflow", abs(float(obs["q_true"]) - q0) < 1e-6, f"{float(obs['q_true']):.3f} m3/d")

# 3 Observations
for n in cfg.GRID_SIZES:
    r, c = obs[f"cells_{n}"].T
    zk = (obs[f"lnk_{n}"] - truth[r, c]) / cfg.SIGMA_LNK; zh = (obs[f"h_{n}"] - h0[r, c]) / cfg.SIGMA_H
    check(f"{n}-point data = reference + noise", np.abs(zk).max() < 4.5 and np.abs(zh).max() < 4.5,
          f"max |noise|/sigma: ln K {np.abs(zk).max():.1f}, heads {np.abs(zh).max():.1f}")
    check(f"{n}-point grid avoids the constant-head columns", (c > 0).all() and (c < cfg.NCOL - 1).all(), f"columns {sorted(int(x) for x in set(c))}")
pos = [q.grid_cells(36).index(tuple(x)) for x in obs["cells_4"]]
check("4-point data identical to the nested 36-point data", np.allclose(obs["lnk_4"], obs["lnk_36"][pos]) and np.allclose(obs["h_4"], obs["h_36"][pos]), "nested")

# 4 ES-MDA against the exact posterior (ln K-only stages)
for s in exact.index:
    rs = metrics.loc[s, "lnk_spread"] / exact.loc[s, "lnk_spread"]; rq = metrics.loc[s, "q_sd"] / exact.loc[s, "q_sd"]
    check(f"{s}: ES-MDA spread close to exact", 0.8 < rs < 1.2, f"ratio ln K {rs:.2f}, outflow sd {rq:.2f}")

# 5 Head fit consistent with the measurement error once 36 heads are assimilated
for s in ["4 K + 36 h", "36 K + 36 h"]:
    f = metrics.loc[s, "head_rmse_36"]
    check(f"{s}: heads fitted to the noise level", f < 3 * cfg.SIGMA_H, f"RMSE {f:.3f} m (sigma {cfg.SIGMA_H} m)")

# 6 Internal consistency of the metrics
d = (rep1.lnk_combined - (rep1.lnk_spread + rep1.lnk_rmse ** 2)).abs().max()
check("ln K combined = spread + RMSE^2", d < 1e-9, f"max difference {d:.1e}")
qc = rep1.q_sd ** 2 * (N - 1) / N + rep1.q_bias ** 2
d = ((rep1.q_combined - qc).abs() / rep1.q_combined).max()
check("Outflow combined = variance + bias^2", d < 1e-9, f"max relative difference {d:.1e}")
check("Prior stage of replicate 1 is the saved prior", abs(rep1.loc["Prior", "lnk_spread"] - prior.var(0, ddof=1).mean()) < 1e-9, "prior")
reps = pd.read_csv((cfg.TABLES + "table_replicates.csv"))
check("All replicates present for every stage", (reps.groupby("stage").size() == cfg.N_REP).all(), f"{cfg.N_REP} replicates")

print(f"{'check':58s} {'result':7s} detail")
for name, ok, detail in results:
    print(f"{name:58s} {'PASS' if ok else 'FAIL':7s} {detail}")
print(f"\n{sum(r[1] for r in results)} of {len(results)} checks passed")
