# Q2 – Worth of conductivity and head data for predicting groundwater outflow

Synthetic twin experiment: a 2-D confined aquifer (MODFLOW 6 via FloPy), a known multi-Gaussian ln K reference field,
progressive assimilation of ln K data and steady heads with ES-MDA, and the outflow through the east boundary as the
prediction that is never assimilated.

## Folder structure

```
Q2_code/
├── README.md                          this file
├── requirements.txt                   Python packages
├── config.py                          all settings (grid, prior, observations, stages, ES-MDA, replicates, folders)
├── q2lib.py                           shared functions (fields, model, ES-MDA, exact posterior, metrics, plot style)
├── 01_reference_and_prior.ipynb       reference field and prior ensemble (Cholesky)
├── 02_model_and_observations.ipynb    forward model, verification, synthetic observations
├── 03_assimilation.ipynb              exact posterior check, ES-MDA at every stage (5 replicates), tables
├── 04_figures.ipynb                   all figures of the report and its annex
├── check_results.py                   automatic verification (23 checks)
└── results/                           created by the notebooks
    ├── data/                          fields, observations, posterior ensembles
    ├── tables/                        csv tables (Tables 1 and 2 of the report)
    ├── figures/                       figures named as in the report (Fig1–Fig4, A1–A8)
    └── mf6_runs/                      MODFLOW 6 working folders
```

## How to run

1. Install the packages in `requirements.txt` and MODFLOW 6; set `MF6_EXE` in `config.py` if `mf6` is not on the PATH.
2. Run the notebooks in order, in this folder:

| Notebook | Run time (approx.) |
|:--|:--|
| 01_reference_and_prior | < 1 min |
| 02_model_and_observations | < 1 min |
| 03_assimilation (5 replicates) | 12–15 min |
| 04_figures | 1 min |

3. Run `python check_results.py`: all 23 checks should pass.

All random seeds are fixed in `config.py`, so the results are reproducible.

## Report figures and tables

| Report | File |
|:--|:--|
| Table 1 | `results/tables/table_stage_metrics.csv` (mean of 5 replicates; spread in `table_stage_metrics_sd.csv`) |
| Table 2 | `results/tables/table_data_worth.csv` (from `table_replicates.csv`) |
| Figures 1–4 | `results/figures/Fig1_…png` to `Fig4_…png` |
| Annex A1–A8 | `results/figures/A1_…png` to `A8_…png` |
